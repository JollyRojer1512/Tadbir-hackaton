package com.example.tadbir;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Settings extends AppCompatActivity {

    TextView textView;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        textView = findViewById(R.id.titlePage);
        textView.setText("Sozlamalar");

        drawerLayout = findViewById(R.id.drawer_layout);
    }

    public void clickMenu(View view){
        //open drawer
        MainActivity.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }

    public void clickHome(View view){
        //redirect activity to home
        MainActivity.redirectActivity(this, MainActivity.class);
    }

    public void clickCategories(View view){
        //redirect activity to categories
        MainActivity.redirectActivity(this, Categories.class);
    }

    public void clickProfile(View view){
        //redirect to activity profile
        MainActivity.redirectActivity(this, Profile.class);
    }

    public void clickAnnouncement(View view){
        //redirect to activity new announcement
        MainActivity.redirectActivity(this, newAnnouncement.class);
    }

    public void clickSettings(View view){
        //recreate
        recreate();
    }

    public void clickShare(View view){
        //redirect to activity share
        MainActivity.redirectActivity(this, Share.class);
    }

    public void clickAbout(View view){
        //redirect to activity about us
        MainActivity.redirectActivity(this, AboutUs.class);
    }

    public void clickExit(View view){
        //close app
        MainActivity.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }

}