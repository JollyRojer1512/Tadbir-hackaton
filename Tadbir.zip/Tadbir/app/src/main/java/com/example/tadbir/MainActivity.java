package com.example.tadbir;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AlertDialogLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    //initializing vars
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //assign var
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    public void clickMenu(View view){
        //open drawer
        openDrawer(drawerLayout);
    }

    public static void openDrawer(DrawerLayout drawerLayout) {
        //open drawer layout
        drawerLayout.openDrawer(GravityCompat.START);
    }

    public void ClickLogo(View view){
        //close drawer
        closeDrawer(drawerLayout);
    }

    public static void closeDrawer(DrawerLayout drawerLayout) {
        //close drawer layout
        //check condition
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            //when drawer is open
            //close drawer
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    public void clickHome(View view){
        //recreate activity
        recreate();
    }

    public void clickCategories(View view){
        //redirect to activity categories
        redirectActivity(this, Categories.class);
    }

    public void clickProfile(View view){
        //redirect to activity profile
        redirectActivity(this, Profile.class);
    }

    public void clickAnnouncement(View view){
        //redirect to activity profile
        redirectActivity(this, newAnnouncement.class);
    }

    public void clickSettings(View view){
        //redirect to activity settings
        redirectActivity(this, Settings.class);
    }

    public void clickShare(View view){
        //redirect to activity share
        redirectActivity(this, Share.class);
    }

    public void clickAbout(View view){
        //redirect to activity about us
        redirectActivity(this, AboutUs.class);
    }

    public void clickExit(View view){
        //close app
        logout(this);
    }

    public static void logout(final Activity activity) {
        //initialize alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        //set title
        builder.setTitle("Chiqish");
        //set message
        builder.setMessage("Haqiqatdan ham chiqishni istaysizmi?");
        //yes button
        builder.setPositiveButton("HA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish activity
                activity.finishAffinity();
                //exit app
                System.exit(0);
            }
        });
        //negative button
        builder.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dismiss dialog
                dialog.dismiss();
            }
        });
        //show dialog
        builder.show();
    }


    public static void redirectActivity(Activity activity, Class aClass) {
        //initialize intent
        Intent i = new Intent(activity, aClass);
        //set flag
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        //start activity
        activity.startActivity(i);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        closeDrawer(drawerLayout);
    }
}